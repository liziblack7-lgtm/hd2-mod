# P-34 Breacher 弹匣补给 Mod

让 **P-34 Breacher** 从补给箱获得更多备用弹匣。

| 字段 | 原值 | 新值 | 含义 |
|---|---|---|---|
| `magazines_refill` | 1 | **2** | 每次补给给几个弹匣 |
| `magazines_max` | 2 | **3** | 最大备弹量 |

**只改这两个字段，其它武器、其它参数一律不动。**

---

## 依赖

- 绝地潜兵2（Steam）+ **Bingus Shared Loader v15 / API 1**
- 构建：已在 `1.8.46015.0` 实测通过

## 安装

把 `data/9ba626afa44a3aa3.patch_0` 及其两个伴随文件放到游戏目录：

```
<游戏>\data\9ba626afa44a3aa3.patch_N                 <- N 用当前空闲槽位
<游戏>\data\9ba626afa44a3aa3.patch_N.gpu_resources   (0 字节)
<游戏>\data\9ba626afa44a3aa3.patch_N.stream          (0 字节)
```

也可以导入 HD2Arsenal（本包是标准的 `data/` 布局）。

> ⚠ **如果用管理器导入，注意别让它覆盖已有槽位。** 管理器按包内编号落槽位，
> 若撞上 loader 所在的槽位会把 loader 顶掉、导致所有 mod 失效。

## 验证

进游戏带上 P-34 Breacher：

- 最大备弹量应显示 **3**（原来 2）
- 补给箱拿一次弹药应给 **2** 个（原来 1 个）

产物在 `%LOCALAPPDATA%\CowboyBingus\Helldivers2\P34MagWrite\`：

| 文件 | 内容 |
|---|---|
| `STATUS.txt` | 第一行是结论 |
| `original_record.hex` | 原始 160 字节备份 |
| `original_summary.txt` | 原始字段值 |
| `..\Logs\P34MagWrite.log` | 每步写入与回读记录 |

成功时日志长这样：

```
backup_written record=0x... refill=1 max=2
write_intent record=0x... offset=144 bytes=8 refill 1->2 max 2->3
applied refill 1->2 max 2->3 readback_ok
```

## 卸载 / 还原

删除放进 `data/` 的那三个文件即可。**所有改动都只在内存里**，移除 mod 就完全还原
（游戏重启后内存会被重新加载）。

## 工作原理（给维护者）

```
game   = GetModuleHandleA("game.dll")        <- 不是 helldivers2.exe
owner  = *(game + 0x346d540)
table  = *(owner + (-13616120))              <- WeaponMagazineComponentData 表
record = table + 8640 + 235*160              <- idx=235，步长 160
字段：  +136 magazine_capacity   +140 magazines
        +144 magazines_refill    +148 magazines_max
```

**改的就是记录 `+144` 起 8 个字节。**

安全性设计：

- 写前逐字段校验身份（`+136=1`、`+140=1`），不吻合**拒写**
- 值域校验：`refill/max` 必须是原值或目标值
- 写前把原始 160 字节备份到磁盘
- 只写 8 字节，写完**回读验证**
- 幂等（已是目标值就跳过）
- 每约 5 秒复查，被换图冲掉自动重打
- 全程不做任何内存扫描

## 已知限制

- **游戏更新会失效**：`owner_rva`、槽位偏移、`idx`、字段偏移都可能变。
  mod 会**安全失败**（不写、记原因），日志里能看到 `identity_mismatch` 之类。
- **客户端本地改动**：HD2 是 P2P 且部分逻辑主机权威，别的玩家未必看到同样效果。
- **有反作弊**（nProtect GameGuard）。本 mod 只在游戏内用只读 + 定点写入，不从外部进程读内存。

---

*构建于 2026-09-26。技术细节与完整踩坑记录见技能目录的 `PLAYBOOK.md`。*
