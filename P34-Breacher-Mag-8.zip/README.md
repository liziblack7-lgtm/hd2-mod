# P34-Breacher-Mag-8

把 **P-34 Breacher**（P-34 破门者）的弹匣相关数值调大。

| 项目 | 原值 | 改后 |
|---|---|---|
| 拾取补给获得的弹药数量 (`magazines_refill`) | 1 | **4** |
| 最大备弹数量 (`magazines_max`) | 2 | **8** |

**只改这两个数值，其余武器参数一律不动。**

## 依赖

- **Bingus Shared Loader v15 或更高**（`API 1`）

> `API 1` 是 loader 自己的 Lua API 等级，写在 `BingusSharedLoader.log` 首行，
> **不是**另一个要装的 mod。只需要 loader 这一个前置。

## 安装

1. 把本 zip 导入 HD2Arsenal。
2. 勾选 **Bingus Shared Loader** + 本 mod，然后点 **Deploy**。
3. 启动游戏。**部署完必须完全重启游戏**，否则读到的是上一次的日志。

## 怎么确认生效了

看这两个文件：

```
%LOCALAPPDATA%\CowboyBingus\Helldivers2\P34Mag8Write\STATUS.txt
%LOCALAPPDATA%\CowboyBingus\Helldivers2\Logs\P34Mag8Write.log
```

`STATUS.txt` 第一行就是结论：

```
result = OK - P-34 refill 1->4, max 2->8 applied
```

日志里应有 `applied refill 1->4 max 2->8 readback_ok`（写入后回读一致）。

## 实现说明

这是个 **Lua 注入型** mod：通过 loader 把 Lua 跑在游戏进程里，再用 FFI 直接读写
`WeaponMagazineComponentData` 表里 P-34 那一条记录（索引 235）的 8 个字节。

安全纪律：写前逐字段校验 → 备份原始 160 字节 → 只写 8 字节 → 回读验证 →
每 5 秒复查（被换图冲掉会自动重打）。全程**只碰这一条记录**，不做任何内存扫描。

写入前的原始字节备份在：

```
%LOCALAPPDATA%\CowboyBingus\Helldivers2\P34Mag8Write\original_record.hex
```

## 已知局限

- **客户端本地改动**：别人（队友）多半看不到，联机时行为可能与队友不一致。
- 游戏更新后偏移可能漂移，届时 mod 会因校验不通过而**拒绝写入**（不会瞎改），
  在 `STATUS.txt` 的 `last_error` 里能看到原因。
- 想还原：在管理器里取消勾选本 mod 并 Deploy（或 Purge）即可，内存改动随之消失。

## 与旧版共存

本包与 `P34-Breacher-Mag-mod`（备弹 3 / 补给 2）是**两个独立 mod**，
模块名、日志、产物目录都不同，可以共存但**别同时勾选**——两者改的是同一字段，会互相覆盖。

## Manifest

- Addon 路径: `mods/dsh/p34_mag8_write`
- 需要 loader: `API 1`（loader v15+）
