# CPG-48 Multi-Passive（一套护甲多个被动）

> **v1.3.1 修复了一个"有概率黑屏 / 启动即卡死"的隐患**：删掉了初始化时的
> `os.execute('mkdir ...')`，改用 kernel32 的 `CreateDirectoryA`。
> 在游戏进程内部 spawn `cmd.exe` 可能被系统拒绝（`0x800700e8` = `ERROR_NO_MORE_PROCESSES`，
> 即"没有更多进程可创建"），表现为「启动即卡死、无响应，强退后弹出终端错误框」。
> 它是**有概率**发生的（取决于当时的进程 / 句柄资源状况），所以有人遇到、有人没遇到。
> 新写法**不产生任何子进程**。
>
> **v1.3.2 修掉了掉帧**（两个来源）：
> ① 扫描预算原来是**固定 20ms/帧**——而 60fps 的帧预算只有 16.7ms，帧率于是被压到约 45，
>    而且扫描逻辑**从不停止**。现在改成"前 40 秒 3ms/帧 → 之后平均约 0.8ms/帧"
>    （实测估算帧率 **45 → 57**）。
> ② `STATUS.txt` / `RECON.txt` 原来是**每 5 秒**无条件重写一次（磁盘 I/O 会造成周期性微卡顿）。
>    现在只在**状态实质变化**时才落盘，周期性的进度只更新内存。
>
> 另外去掉了"扫 N 轮后放弃"的逻辑——原来它会把状态标成 `FAILED`，但 tick **照样继续全速扫**，
> 既误导又不省开销。

让 **CPG-48 Sapper**（以及所有使用同一个「防震内衬／掷弹兵型」被动的护甲）**同时拥有 5 条护甲被动的效果**。

| 被动 | 游戏内名字 | 效果 |
| --- | --- | --- |
| 本体（保留） | Concussive Padding, Grenadier 防震内衬（掷弹兵型） | 爆炸伤害抗性 **50%**、投掷物初始／携带上限 **+2** |
| **+** Extra Padding | 额外垫料 | 护甲值 **+50** |
| **+** Blunt-Force Mitigation | 钝击创伤缓和 | 抗击退／被击倒 **−30%**、撞击与碰撞伤害 **−30%**、护甲值 **+25** |
| **+** Oxygenator | 氧合器 | 步行速度 **+10%**、奔跑速度 **+10%**、滑铲更快更久 |
| **+** Med-Kit | 急救包（医疗包） | 针剂携带上限 **+2**、针剂持续时间 **+2 秒** |

合并后护甲值一共 **+75**，修饰符共 **10 条**。

> **想增删被动？** mod 顶部 `TARGETS` 就是全部来源，第 1 条是本体（护甲自带的），
> 后面每条加一行即可（从离线表里查到它的 `PassiveBonus` / `Name` loc key / 修饰符 id）。
> 数值不硬编码 —— 运行时从游戏内存里把来源记录的修饰符抄过来。

---

## 原理

《绝地潜兵 2》的护甲被动表是一串独立的 `LDLD` 子数据块（类型哈希 `0x63CE0FEB`，本版本共 32 条）。
每条记录用 `PassiveModifierOffset / PassiveModifierCount` 指向自己的修饰符数组：

```
data[+0]  PassiveBonus  u32   ← 护甲装配的被动枚举值（CPG-48 那条 = 36）
data[+4]  Name          u32   ← 本地化 loc key（CPG-48 那条 = 141575155）
data[+16] PassiveModifierOffset i64
data[+24] PassiveModifierCount  i64
...
修饰符 16 字节: { ModifierId u32 | ModifierType u32 | Value f32 | Description u32 }
ModifierType: 0=Set  1=Add  2=Multiply  3=Time
```

护甲装配只能挂**一条**被动，所以「多个被动」只能靠把修饰符**并到同一条记录上**。

本 mod 的做法：

1. **用记录结构自身的 8 字节指纹定位**（`PassiveBonus | Name`）。四条目标记录各有唯一指纹，
   各自独立命中 —— 不依赖 `LDLD` 外壳、不依赖记录链、不需要知道表在哪。
   （游戏即使把每条记录单独分配也能找到。）
2. 从本体 + `PB=1`（额外垫料）+ `PB=40`（钝击创伤缓和）+ `PB=38`（氧合器）
   **读出它们真实的修饰符**（不硬编码数值，跟着游戏版本走）；
   并且每条的修饰符 id 集合必须与离线权威表**逐一对上**，否则整轮拒绝。
3. 同 `(ModifierId, ModifierType, Description)` 的 `Add` 相加去重
   （护甲值 `Add 1.0` 与 `Add 0.5` 合成 `Add 1.5` = +75），得到 8 条修饰符。
4. `VirtualAlloc` 一块自己的缓冲区写入这 8 条，然后把本体的
   `PassiveModifierOffset` 指向该缓冲区、`PassiveModifierCount` 改成 8。

### ★ 偏移语义的三种情况都支持

`PassiveModifierOffset` 在文件里是「相对记录 data 起点的偏移」（就是 56），
但游戏加载时可能已经把它重定位成别的形式。mod 会把三种都试一遍，用修饰符 id 判定真身，
写回时按同一语义**反算**：

| 游戏把它当成 | 读的时候看哪 | 写回时写什么 |
| --- | --- | --- |
| 绝对指针 | `pmoff` | 缓冲区地址 `B` |
| 相对 data 起点的偏移 | `data + pmoff` | `B - data` |
| 相对 LDLD magic 的偏移 | `(data-24) + pmoff` | `B - (data-24)` |

偏移是 64 位整数，可以指向进程里任意地址 —— **所以偏移语义也能外挂数组**。

## 安全阀

* 每条记录必须同时满足：指纹对上 **且** 修饰符 id 集合完全对上，否则不用。
* 写前备份 16 字节，写后**按同一语义再解一遍**，确认真的能读回我们那块缓冲区，不符立刻回滚。
* 每 5 秒复查全部实例，被游戏冲掉就重打。
* 只用 `VirtualAlloc` 自己的缓冲区，不改游戏任何别的结构。
* **不写 Lua 堆**：mod 自己读内存产生的 Lua 字符串释放后字节仍留堆里（内容和刚读到的
  游戏数据一模一样），会被误当成表的副本。mod 用 `ffi.cast('const char*', str)` 拿到
  字符串地址、`VirtualQuery` 出所属分配并**在扫描时排除**，所以补丁只会打到真正的游戏内存。

## 使用

1. 装好 **Bingus Shared Loader v15 / API 1**（只需加载器本身）。
2. 用加载器的导入功能导入本压缩包／文件夹，然后 **Deploy**。
3. ⚠ **导入/部署之后必须完全退出游戏再重新启动**。
   加载器只在**进程启动时**读一次 mod 列表，没有热重载；先开游戏再部署 = 这一局不会有任何变化
   （日志里也看不到这个 mod）。这一点是本 mod 第一次交付时「没生效」的真实原因。
4. 进游戏后**重新装备一次 CPG-48**（或退到飞船再进任务），被动描述/护甲值才会重算。

## 生效范围

被动记录是**共享**的：所有使用「防震内衬／掷弹兵型」的护甲都会一起获得这 4 条被动。
这是「合并到同一条被动」这个方案本身的特性。

## 日志 / 排错

加载器启用本 mod 后，会写到：

```
%LOCALAPPDATA%\CowboyBingus\Helldivers2\Cpg48Multi\
    STATUS.txt   当前状态（phase / encoding / found / instances / applied / 本体地址 / 缓冲区）
    RECON.txt    只读侦察明细：每条记录认在哪、语义判定、原始修饰符、合并后的 8 条、每个实例
    run.log      事件流水
```

* `STATUS.txt` 里 `phase = OK - 已应用 N 个实例 (ptr|off(data)|off(data-24))` 表示已改写成功。
* `found = 4/4` 表示四条记录都认出来了；`base instances` 是本体被找到的副本数
  （大于 1 是正常的：同一份表在内存里可能有多份）。
* `phase = FAILED - 扫完 N 轮: 找到 x/4` 表示扫描找不到某些记录，`RECON.txt` 会记录候选
  以及"指纹命中但修饰符对不上"的原因。
* `tick 内部错误` 说明 mod 自身出错（这种错误**不会**被静默吞掉，会写进日志）。

关掉 mod（或在加载器里禁用）即恢复原状：本 mod 只改游戏内存，不落盘、不动游戏文件。

## 已验证状态

✅ **已实机验证生效**（2026-09-28，v1.3.0）：护甲同时拥有上述 **5 条**被动。

实机读数（`STATUS.txt`）：

```
version = 1.3.0     phase = done          encoding = ptr
found = 5/5         instances = 5 (base 1)
applied = 1         reapplied = 0         self_hits = 0
merged_n = 10       base_data = 0x1bcadf20e58   buf = 0x1bcc9eb0000
```

`run.log` 里 `f361` 帧认下全部 5 条记录并完成改写（全地址空间 8587 个内存区 / 7853 MB，
约 12 秒）。`RECON.txt` 里合并出的 10 条修饰符与离线权威表**逐条一致** ——
这是"离线推导"与"游戏实机数据"的完整闭环。

（更早的 4 被动版 v1.2.3 也实测生效：`found = 4/4`、`merged_n = 8`、`f347` 帧完成。）

要点：

* 游戏对 `PassiveModifierOffset` 用的是**绝对指针**语义（`encoding = ptr`），
  所以做法是 `VirtualAlloc` 一块自己的缓冲区、把本体的偏移改成指向它。
* `reapplied = 0`：改写后没有被游戏冲掉（改名后一直维持）。
* `self_hits = 0`：没有把补丁打到"自己读进来的内存副本"上。
* 数据依据是**离线权威来源**：游戏自带 `data/game/generated_customization_passive_bonuses.dl_bin`
  的明文副本（32 条记录）+ 社区 `HelldiversData` 的被动枚举表 + 官方 Wiki 的效果数值，
  三者逐字段互相印证（见 mod 文件顶部注释的对照表）。
* 上机前用**离线仿真 + 变异测试**跑通 9 个场景（三种偏移语义各自成功；来源被改、本体被改两种
  变异各自被拒绝；外加四个"环境突变"：`tostring` 不带 `0x` / `tostring` 抛错 /
  加载器缺 `api` 字段 / 完全没有加载器），并且是对**打包产物里抽出来的正文**跑的。

---

## English summary

Gives **CPG-48 Sapper** (and every armor sharing the same *Concussive Padding, Grenadier* passive)
four armor passives at once: **Concussive Padding, Grenadier** (the native one) + **Extra Padding**
(+50 armor rating) + **Blunt-Force Mitigation** (stagger −30%, impact/collision damage −30%,
armor rating +25) + **Oxygenator** (walk/run +10%, better slides).

How: the armor kit can only reference one passive, so the passive-bonus table record for
`PassiveBonus = 36` gets its modifier array relocated — the mod harvests the real modifier structs
from records 36/1/40/38 (validated against an offline authoritative table), merges them (duplicate
`Add` modifiers on the same id are summed → armor rating +75), writes the merged array into a
`VirtualAlloc` buffer and repoints `PassiveModifierOffset` / raises `PassiveModifierCount`.
Read-only if the offsets turn out to be relative offsets rather than pointers (it refuses instead
of writing). Memory-only: disable the mod to restore.
